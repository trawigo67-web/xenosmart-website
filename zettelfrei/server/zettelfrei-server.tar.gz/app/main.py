"""Zettelfrei Web – Backend.

Ein kleiner, selbst gehosteter Server: Familienkonten, Login, 30 Tage Testphase,
Dokumentenspeicher für Briefe, Datei-Upload und KI-Auslesen (OpenAI oder Gemini).
Daten liegen in SQLite + Dateien unter DATA_DIR (Standard /data).
"""
import base64, hashlib, hmac, json, os, re, secrets, sqlite3, time
from contextlib import closing
from datetime import datetime, timedelta, timezone
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Request, Response, UploadFile, File, Depends
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

DATA = Path(os.environ.get("DATA_DIR", "/data"))
FILES = DATA / "files"
DB_PATH = DATA / "zettelfrei.db"
TRIAL_DAYS = int(os.environ.get("TRIAL_DAYS", "30"))
AI_DAILY_LIMIT = int(os.environ.get("AI_DAILY_LIMIT", "80"))
AI_PROVIDER = os.environ.get("AI_PROVIDER", "openai").lower()
OPENAI_KEY = os.environ.get("OPENAI_API_KEY", "")
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4.1-mini")
GEMINI_KEY = os.environ.get("GEMINI_API_KEY", "")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")
ADMIN_EMAILS = {e.strip().lower() for e in os.environ.get("ADMIN_EMAILS", "").split(",") if e.strip()}
COOKIE = "zf_session"
SECURE_COOKIE = os.environ.get("SECURE_COOKIE", "1") == "1"
COLLECTIONS = {"letters", "members", "settings", "feedback"}
ID_RE = re.compile(r"^[A-Za-z0-9_\-.:@+~]{1,120}$")
MAX_UPLOAD = 20 * 1024 * 1024
ALLOWED_TYPES = {"image/jpeg", "image/png", "image/webp", "image/gif", "application/pdf"}

DATA.mkdir(parents=True, exist_ok=True)
FILES.mkdir(parents=True, exist_ok=True)
CONFIG = DATA / "config.json"


def load_config():
    global AI_PROVIDER, OPENAI_KEY, GEMINI_KEY
    try:
        cfg = json.loads(CONFIG.read_text())
    except Exception:
        return
    if cfg.get("openai_key"):
        OPENAI_KEY = cfg["openai_key"]
    if cfg.get("gemini_key"):
        GEMINI_KEY = cfg["gemini_key"]
    if cfg.get("provider") in ("openai", "gemini"):
        AI_PROVIDER = cfg["provider"]


load_config()


def now() -> datetime:
    return datetime.now(timezone.utc)


def iso(d: datetime) -> str:
    return d.isoformat(timespec="seconds")


def db() -> sqlite3.Connection:
    c = sqlite3.connect(DB_PATH, timeout=10)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    return c


def init_db():
    with closing(db()) as c, c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS families(
              id TEXT PRIMARY KEY, name TEXT, invite_code TEXT UNIQUE, plan TEXT DEFAULT 'trial',
              trial_ends TEXT, paid_until TEXT, created TEXT);
            CREATE TABLE IF NOT EXISTS users(
              id TEXT PRIMARY KEY, email TEXT UNIQUE, pw_hash TEXT, name TEXT, family_id TEXT REFERENCES families(id),
              role TEXT, member_id TEXT, created TEXT);
            CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id TEXT REFERENCES users(id) ON DELETE CASCADE, expires TEXT);
            CREATE TABLE IF NOT EXISTS docs(
              family_id TEXT, col TEXT, id TEXT, data TEXT, updated TEXT, PRIMARY KEY(family_id, col, id));
            CREATE TABLE IF NOT EXISTS files(
              id TEXT PRIMARY KEY, family_id TEXT, content_type TEXT, size INTEGER, created TEXT);
            CREATE TABLE IF NOT EXISTS ai_usage(family_id TEXT, day TEXT, n INTEGER, PRIMARY KEY(family_id, day));
            CREATE TABLE IF NOT EXISTS login_attempts(key TEXT PRIMARY KEY, n INTEGER, since REAL);
            """
        )


init_db()
app = FastAPI(title="Zettelfrei", docs_url=None, redoc_url=None, openapi_url=None)


# ----------------------------------------------------------------- Sicherheit
def hash_pw(pw: str) -> str:
    salt = secrets.token_bytes(16)
    h = hashlib.scrypt(pw.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return base64.b64encode(salt + h).decode()


def check_pw(pw: str, stored: str) -> bool:
    raw = base64.b64decode(stored)
    salt, h = raw[:16], raw[16:]
    h2 = hashlib.scrypt(pw.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return hmac.compare_digest(h, h2)


def token_hash(t: str) -> str:
    return hashlib.sha256(t.encode()).hexdigest()


def rate_limit(key: str, limit: int = 10, window: int = 900):
    with closing(db()) as c, c:
        r = c.execute("SELECT n, since FROM login_attempts WHERE key=?", (key,)).fetchone()
        t = time.time()
        if not r or t - r["since"] > window:
            c.execute("INSERT OR REPLACE INTO login_attempts VALUES(?,?,?)", (key, 1, t))
            return
        if r["n"] >= limit:
            raise HTTPException(429, "Zu viele Versuche. Bitte in 15 Minuten erneut probieren.")
        c.execute("UPDATE login_attempts SET n=n+1 WHERE key=?", (key,))


def new_session(resp: Response, user_id: str):
    t = secrets.token_urlsafe(32)
    with closing(db()) as c, c:
        c.execute("INSERT INTO sessions VALUES(?,?,?)", (token_hash(t), user_id, iso(now() + timedelta(days=60))))
    resp.set_cookie(COOKIE, t, max_age=60 * 86400, httponly=True, secure=SECURE_COOKIE, samesite="lax", path="/")


def current(request: Request) -> dict:
    t = request.cookies.get(COOKIE)
    if not t:
        raise HTTPException(401, "Nicht angemeldet")
    with closing(db()) as c:
        r = c.execute(
            """SELECT u.*, f.name AS family_name, f.invite_code, f.plan, f.trial_ends, f.paid_until
               FROM sessions s JOIN users u ON u.id=s.user_id JOIN families f ON f.id=u.family_id
               WHERE s.token_hash=? AND s.expires>?""",
            (token_hash(t), iso(now())),
        ).fetchone()
    if not r:
        raise HTTPException(401, "Sitzung abgelaufen")
    return dict(r)


def access(u: dict) -> dict:
    """Zugangsstatus: aktiv in Testphase, bezahlt oder abgelaufen."""
    n = now()
    paid = u.get("paid_until") and datetime.fromisoformat(u["paid_until"]) > n
    trial_end = datetime.fromisoformat(u["trial_ends"])
    days_left = max(0, (trial_end - n).days + (1 if (trial_end - n).seconds > 0 else 0))
    active = bool(paid) or trial_end > n
    return {"active": active, "paid": bool(paid), "trialEnds": u["trial_ends"], "trialDaysLeft": days_left, "plan": u["plan"]}


def require_active(u: dict):
    if not access(u)["active"]:
        raise HTTPException(402, "Die Testphase ist abgelaufen.")


def is_admin(u: dict) -> bool:
    return u["email"].lower() in ADMIN_EMAILS


# ------------------------------------------------------------------- Konten
def put_doc(c, fam, col, id_, data):
    c.execute(
        "INSERT OR REPLACE INTO docs VALUES(?,?,?,?,?)",
        (fam, col, id_, json.dumps(data, ensure_ascii=False), iso(now())),
    )


COLORS = ["#1d4ed8", "#be185d", "#7c3aed", "#0f766e", "#c2410c", "#4d7c0f", "#b45309", "#475569"]


def valid_email(e: str) -> bool:
    return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", e)) and len(e) <= 200


@app.post("/api/register")
async def register(request: Request, response: Response):
    b = await request.json()
    email = str(b.get("email", "")).strip().lower()
    pw = str(b.get("password", ""))
    name = str(b.get("name", "")).strip()[:60]
    fam_name = str(b.get("familyName", "")).strip()[:60]
    rate_limit("reg:" + (request.client.host if request.client else "?"), 8, 3600)
    if not valid_email(email) or len(pw) < 8 or not name:
        raise HTTPException(400, "Bitte Name, gültige E-Mail und ein Passwort mit mindestens 8 Zeichen angeben.")
    fid, uid = "f" + secrets.token_hex(8), "u" + secrets.token_hex(8)
    code = secrets.token_hex(3).upper()
    mid = "m" + uid
    with closing(db()) as c, c:
        if c.execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone():
            raise HTTPException(409, "Diese E-Mail ist schon registriert. Bitte anmelden.")
        c.execute(
            "INSERT INTO families VALUES(?,?,?,?,?,?,?)",
            (fid, fam_name or name, code, "trial", iso(now() + timedelta(days=TRIAL_DAYS)), None, iso(now())),
        )
        c.execute("INSERT INTO users VALUES(?,?,?,?,?,?,?,?)", (uid, email, hash_pw(pw), name, fid, "owner", mid, iso(now())))
        put_doc(c, fid, "members", mid, {"name": name, "role": "adult", "color": COLORS[0], "order": 0, "userId": uid})
        put_doc(c, fid, "settings", "main", {"familyName": fam_name})
    new_session(response, uid)
    return {"ok": True}


@app.post("/api/join")
async def join(request: Request, response: Response):
    b = await request.json()
    email = str(b.get("email", "")).strip().lower()
    pw = str(b.get("password", ""))
    name = str(b.get("name", "")).strip()[:60]
    code = str(b.get("code", "")).strip().upper()
    rate_limit("join:" + (request.client.host if request.client else "?"), 10, 3600)
    if not valid_email(email) or len(pw) < 8 or not name or not code:
        raise HTTPException(400, "Bitte Einladungscode, Name, E-Mail und Passwort (mind. 8 Zeichen) angeben.")
    with closing(db()) as c, c:
        f = c.execute("SELECT * FROM families WHERE invite_code=?", (code,)).fetchone()
        if not f:
            raise HTTPException(404, "Einladungscode nicht gefunden.")
        if c.execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone():
            raise HTTPException(409, "Diese E-Mail ist schon registriert. Bitte anmelden.")
        n_users = c.execute("SELECT COUNT(*) FROM users WHERE family_id=?", (f["id"],)).fetchone()[0]
        if n_users >= 6:
            raise HTTPException(403, "Diese Familie hat schon 6 Personen.")
        uid = "u" + secrets.token_hex(8)
        mid = "m" + uid
        c.execute("INSERT INTO users VALUES(?,?,?,?,?,?,?,?)", (uid, email, hash_pw(pw), name, f["id"], "member", mid, iso(now())))
        n_members = c.execute("SELECT COUNT(*) FROM docs WHERE family_id=? AND col='members'", (f["id"],)).fetchone()[0]
        put_doc(c, f["id"], "members", mid, {"name": name, "role": "adult", "color": COLORS[n_members % len(COLORS)], "order": n_members, "userId": uid})
    new_session(response, uid)
    return {"ok": True}


@app.post("/api/login")
async def login(request: Request, response: Response):
    b = await request.json()
    email = str(b.get("email", "")).strip().lower()
    pw = str(b.get("password", ""))
    rate_limit("login:" + email, 10, 900)
    with closing(db()) as c:
        u = c.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    if not u or not check_pw(pw, u["pw_hash"]):
        raise HTTPException(401, "E-Mail oder Passwort falsch.")
    new_session(response, u["id"])
    return {"ok": True}


@app.post("/api/logout")
async def logout(request: Request, response: Response):
    t = request.cookies.get(COOKIE)
    if t:
        with closing(db()) as c, c:
            c.execute("DELETE FROM sessions WHERE token_hash=?", (token_hash(t),))
    response.delete_cookie(COOKIE, path="/")
    return {"ok": True}


@app.get("/api/me")
def me(u: dict = Depends(current)):
    return {
        "user": {"id": u["id"], "email": u["email"], "name": u["name"], "role": u["role"], "memberId": u["member_id"], "admin": is_admin(u)},
        "family": {"id": u["family_id"], "name": u["family_name"], "inviteCode": u["invite_code"]},
        "access": access(u),
    }


@app.post("/api/password")
async def change_pw(request: Request, u: dict = Depends(current)):
    b = await request.json()
    if not check_pw(str(b.get("old", "")), u["pw_hash"]) or len(str(b.get("new", ""))) < 8:
        raise HTTPException(400, "Altes Passwort falsch oder neues zu kurz.")
    with closing(db()) as c, c:
        c.execute("UPDATE users SET pw_hash=? WHERE id=?", (hash_pw(str(b["new"])), u["id"]))
    return {"ok": True}


@app.delete("/api/account")
def delete_account(response: Response, u: dict = Depends(current)):
    """Konto löschen. Inhaber: ganze Familie mit allen Briefen und Fotos. Mitglied: nur das eigene Konto."""
    import shutil
    with closing(db()) as c, c:
        if u["role"] == "owner":
            fam = u["family_id"]
            c.execute("DELETE FROM docs WHERE family_id=?", (fam,))
            c.execute("DELETE FROM files WHERE family_id=?", (fam,))
            c.execute("DELETE FROM ai_usage WHERE family_id=?", (fam,))
            c.execute("DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE family_id=?)", (fam,))
            c.execute("DELETE FROM users WHERE family_id=?", (fam,))
            c.execute("DELETE FROM families WHERE id=?", (fam,))
            shutil.rmtree(FILES / fam, ignore_errors=True)
        else:
            c.execute("DELETE FROM docs WHERE family_id=? AND col='members' AND id=?", (u["family_id"], u["member_id"]))
            c.execute("DELETE FROM sessions WHERE user_id=?", (u["id"],))
            c.execute("DELETE FROM users WHERE id=?", (u["id"],))
    response.delete_cookie(COOKIE, path="/")
    return {"ok": True}


# --------------------------------------------------------------- Dokumente
def check_col(col: str, id_: str | None = None):
    if col not in COLLECTIONS or (id_ is not None and not ID_RE.match(id_)):
        raise HTTPException(400, "Ungültiger Pfad")


@app.get("/api/col/{col}")
def list_col(col: str, u: dict = Depends(current)):
    check_col(col)
    with closing(db()) as c:
        rows = c.execute("SELECT id, data, updated FROM docs WHERE family_id=? AND col=?", (u["family_id"], col)).fetchall()
    return {"docs": [{"id": r["id"], "data": json.loads(r["data"]), "updated": r["updated"]} for r in rows]}


@app.get("/api/doc/{col}/{id_}")
def get_doc(col: str, id_: str, u: dict = Depends(current)):
    check_col(col, id_)
    with closing(db()) as c:
        r = c.execute("SELECT data FROM docs WHERE family_id=? AND col=? AND id=?", (u["family_id"], col, id_)).fetchone()
    return {"exists": bool(r), "data": json.loads(r["data"]) if r else None}


def merge(a: dict, b: dict) -> dict:
    out = dict(a)
    for k, v in b.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = merge(out[k], v)
        else:
            out[k] = v
    return out


@app.put("/api/doc/{col}/{id_}")
async def set_doc(col: str, id_: str, request: Request, u: dict = Depends(current)):
    check_col(col, id_)
    if col != "feedback":
        require_active(u)
    body = await request.body()
    if len(body) > 256 * 1024:
        raise HTTPException(413, "Dokument zu groß")
    data = json.loads(body)
    if not isinstance(data, dict):
        raise HTTPException(400, "Ungültige Daten")
    if col == "feedback":
        data = {"text": str(data.get("text", ""))[:4000], "who": u["name"], "email": u["email"], "family": u["family_name"], "at": iso(now()), "lang": str(data.get("lang", ""))[:5]}
    with closing(db()) as c, c:
        if col == "letters":
            n = c.execute("SELECT COUNT(*) FROM docs WHERE family_id=? AND col='letters'", (u["family_id"],)).fetchone()[0]
            if n >= 5000:
                raise HTTPException(507, "Speicher voll")
        put_doc(c, u["family_id"], col, id_, data)
    return {"ok": True}


@app.patch("/api/doc/{col}/{id_}")
async def update_doc(col: str, id_: str, request: Request, u: dict = Depends(current)):
    check_col(col, id_)
    require_active(u)
    patch = await request.json()
    with closing(db()) as c, c:
        r = c.execute("SELECT data FROM docs WHERE family_id=? AND col=? AND id=?", (u["family_id"], col, id_)).fetchone()
        if not r:
            raise HTTPException(404, "Nicht gefunden")
        put_doc(c, u["family_id"], col, id_, merge(json.loads(r["data"]), patch))
    return {"ok": True}


@app.delete("/api/doc/{col}/{id_}")
def delete_doc(col: str, id_: str, u: dict = Depends(current)):
    check_col(col, id_)
    with closing(db()) as c, c:
        c.execute("DELETE FROM docs WHERE family_id=? AND col=? AND id=?", (u["family_id"], col, id_))
    return {"ok": True}


# ------------------------------------------------------------------ Dateien
@app.post("/api/upload")
async def upload(file: UploadFile = File(...), u: dict = Depends(current)):
    require_active(u)
    ct = (file.content_type or "").split(";")[0]
    if ct not in ALLOWED_TYPES:
        raise HTTPException(415, "Nur Fotos (JPG, PNG, WebP) und PDF")
    data = await file.read(MAX_UPLOAD + 1)
    if len(data) > MAX_UPLOAD:
        raise HTTPException(413, "Datei zu groß (max. 20 MB)")
    fid = "a" + secrets.token_hex(12)
    d = FILES / u["family_id"]
    d.mkdir(parents=True, exist_ok=True)
    (d / fid).write_bytes(data)
    with closing(db()) as c, c:
        c.execute("INSERT INTO files VALUES(?,?,?,?,?)", (fid, u["family_id"], ct, len(data), iso(now())))
    return {"id": fid, "url": "/_blob/" + fid, "sizeBytes": len(data), "contentType": ct}


@app.get("/_blob/{fid}")
def blob(fid: str, u: dict = Depends(current)):
    with closing(db()) as c:
        r = c.execute("SELECT * FROM files WHERE id=? AND family_id=?", (fid, u["family_id"])).fetchone()
    if not r:
        raise HTTPException(404)
    return FileResponse(FILES / u["family_id"] / fid, media_type=r["content_type"], headers={"Cache-Control": "private, max-age=86400"})


@app.delete("/api/upload/{fid}")
def delete_file(fid: str, u: dict = Depends(current)):
    with closing(db()) as c, c:
        r = c.execute("SELECT 1 FROM files WHERE id=? AND family_id=?", (fid, u["family_id"])).fetchone()
        if r:
            c.execute("DELETE FROM files WHERE id=?", (fid,))
            (FILES / u["family_id"] / fid).unlink(missing_ok=True)
    return {"ok": True}


# ----------------------------------------------------------------------- KI
def count_ai(fam: str):
    day = now().strftime("%Y-%m-%d")
    with closing(db()) as c, c:
        r = c.execute("SELECT n FROM ai_usage WHERE family_id=? AND day=?", (fam, day)).fetchone()
        if r and r["n"] >= AI_DAILY_LIMIT:
            raise HTTPException(429, "Tageslimit für KI erreicht. Morgen geht es weiter.")
        c.execute("INSERT INTO ai_usage VALUES(?,?,1) ON CONFLICT(family_id,day) DO UPDATE SET n=n+1", (fam, day))


async def call_openai(prompt: str, images: list[dict], want_json: bool) -> str:
    content = [{"type": "text", "text": prompt}] + [
        {"type": "image_url", "image_url": {"url": f"data:{i['type']};base64,{i['data']}", "detail": "high"}} for i in images
    ]
    body = {"model": OPENAI_MODEL, "messages": [{"role": "user", "content": content}], "temperature": 0.2}
    if want_json:
        body["response_format"] = {"type": "json_object"}
    async with httpx.AsyncClient(timeout=120) as cl:
        r = await cl.post("https://api.openai.com/v1/chat/completions", json=body, headers={"Authorization": f"Bearer {OPENAI_KEY}"})
    if r.status_code != 200:
        raise HTTPException(502, "KI-Dienst nicht erreichbar")
    return r.json()["choices"][0]["message"]["content"]


async def call_gemini(prompt: str, images: list[dict], want_json: bool) -> str:
    parts = [{"text": prompt}] + [{"inline_data": {"mime_type": i["type"], "data": i["data"]}} for i in images]
    body = {"contents": [{"role": "user", "parts": parts}], "generationConfig": {"temperature": 0.2}}
    if want_json:
        body["generationConfig"]["responseMimeType"] = "application/json"
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent"
    async with httpx.AsyncClient(timeout=120) as cl:
        r = await cl.post(url, json=body, headers={"x-goog-api-key": GEMINI_KEY})
    if r.status_code != 200:
        raise HTTPException(502, "KI-Dienst nicht erreichbar")
    cand = r.json().get("candidates") or []
    return "".join(p.get("text", "") for p in (cand[0]["content"]["parts"] if cand else []))


@app.post("/api/ai")
async def ai(request: Request, u: dict = Depends(current)):
    require_active(u)
    b = await request.json()
    prompt = str(b.get("prompt", ""))[:60000]
    images = b.get("images") or []
    if not prompt or len(images) > 8:
        raise HTTPException(400, "Ungültige Anfrage")
    imgs = []
    for i in images:
        t = str(i.get("type", ""))
        d = str(i.get("data", ""))
        if t not in {"image/jpeg", "image/png", "image/webp"} or len(d) > 12_000_000:
            raise HTTPException(415, "Bildformat nicht unterstützt")
        imgs.append({"type": t, "data": d})
    count_ai(u["family_id"])
    want_json = bool(b.get("json"))
    if AI_PROVIDER == "mock":  # nur fuer lokale Tests
        return {"text": json.dumps({"betreff": "Testbrief", "absender": "Test GmbH", "kategorie": "rechnung", "zusammenfassung": "Testantwort.", "aufgaben": ["Pruefen"], "frist": {"datum": None}}) if want_json else "Testantwort der KI."}
    if AI_PROVIDER == "gemini" and GEMINI_KEY:
        text = await call_gemini(prompt, imgs, want_json)
    elif OPENAI_KEY:
        text = await call_openai(prompt, imgs, want_json)
    elif GEMINI_KEY:
        text = await call_gemini(prompt, imgs, want_json)
    else:
        raise HTTPException(503, "KI ist auf dem Server noch nicht eingerichtet.")
    return {"text": text}


# ------------------------------------------------------------------- Admin
def admin_only(u: dict = Depends(current)):
    if not is_admin(u):
        raise HTTPException(403)
    return u


@app.get("/api/admin/overview")
def admin_overview(u: dict = Depends(admin_only)):
    with closing(db()) as c:
        fams = c.execute(
            """SELECT f.*, (SELECT COUNT(*) FROM users WHERE family_id=f.id) AS users,
               (SELECT COUNT(*) FROM docs WHERE family_id=f.id AND col='letters') AS letters,
               (SELECT GROUP_CONCAT(email, ', ') FROM users WHERE family_id=f.id) AS emails
               FROM families f ORDER BY created DESC"""
        ).fetchall()
        fb = c.execute("SELECT data FROM docs WHERE col='feedback' ORDER BY updated DESC LIMIT 300").fetchall()
    return {"families": [dict(r) for r in fams], "feedback": [json.loads(r["data"]) for r in fb]}


@app.post("/api/admin/family/{fid}")
async def admin_family(fid: str, request: Request, u: dict = Depends(admin_only)):
    b = await request.json()
    with closing(db()) as c, c:
        if "plan" in b and b["plan"] in {"trial", "family", "pro"}:
            c.execute("UPDATE families SET plan=? WHERE id=?", (b["plan"], fid))
        if "extendDays" in b:
            c.execute("UPDATE families SET trial_ends=? WHERE id=?", (iso(now() + timedelta(days=int(b["extendDays"]))), fid))
        if "paidMonths" in b:
            c.execute("UPDATE families SET paid_until=? WHERE id=?", (iso(now() + timedelta(days=31 * int(b["paidMonths"]))), fid))
    return {"ok": True}


@app.get("/api/admin/ai")
def admin_ai_status(u: dict = Depends(admin_only)):
    def mask(k):
        return (k[:5] + "…" + k[-4:]) if k else ""
    return {"provider": AI_PROVIDER, "openai": mask(OPENAI_KEY), "gemini": mask(GEMINI_KEY), "model": OPENAI_MODEL if AI_PROVIDER == "openai" else GEMINI_MODEL}


@app.post("/api/admin/ai")
async def admin_ai_set(request: Request, u: dict = Depends(admin_only)):
    b = await request.json()
    key = str(b.get("key", "")).strip()
    if key.startswith("sk-"):
        prov, field = "openai", "openai_key"
    elif key.startswith("AIza"):
        prov, field = "gemini", "gemini_key"
    else:
        raise HTTPException(400, "Unbekanntes Format. OpenAI-Schlüssel beginnen mit sk-, Gemini-Schlüssel mit AIza.")
    # Schlüssel kurz prüfen, bevor er gespeichert wird
    async with httpx.AsyncClient(timeout=20) as cl:
        if prov == "openai":
            r = await cl.get("https://api.openai.com/v1/models", headers={"Authorization": f"Bearer {key}"})
        else:
            r = await cl.get("https://generativelanguage.googleapis.com/v1beta/models", headers={"x-goog-api-key": key})
    if r.status_code != 200:
        raise HTTPException(400, "Der Schlüssel wurde vom Anbieter abgelehnt. Bitte prüfen.")
    try:
        cfg = json.loads(CONFIG.read_text())
    except Exception:
        cfg = {}
    cfg[field] = key
    cfg["provider"] = prov
    CONFIG.write_text(json.dumps(cfg))
    os.chmod(CONFIG, 0o600)
    load_config()
    return {"ok": True, "provider": prov}


@app.get("/api/health")
def health():
    return {"ok": True, "ai": bool(OPENAI_KEY or GEMINI_KEY)}


# ----------------------------------------------------------------- Frontend
STATIC = Path(__file__).parent / "static"
app.mount("/fonts", StaticFiles(directory=STATIC / "fonts"), name="fonts")


@app.get("/", response_class=HTMLResponse)
def index():
    return FileResponse(STATIC / "index.html", headers={"Cache-Control": "no-cache"})


@app.get("/manifest.webmanifest")
def manifest():
    return FileResponse(STATIC / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/icon.svg")
def icon():
    return FileResponse(STATIC / "icon.svg", media_type="image/svg+xml")


@app.get("/admin", response_class=HTMLResponse)
def admin_page():
    return FileResponse(STATIC / "admin.html", headers={"Cache-Control": "no-cache"})


@app.middleware("http")
async def security_headers(request: Request, call_next):
    resp = await call_next(request)
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["Referrer-Policy"] = "same-origin"
    resp.headers["X-Frame-Options"] = "DENY"
    return resp
