"""Mailcut (früher Zettelfrei) Web – Backend.

Ein kleiner, selbst gehosteter Server: Familienkonten, Login, 30 Tage Testphase,
Dokumentenspeicher für Briefe, Datei-Upload und KI-Auslesen (Claude, OpenAI oder Gemini)
mit KI-Kontingenten pro Familie und Monat.
Daten liegen in SQLite + Dateien unter DATA_DIR (Standard /data).
"""
import base64, hashlib, hmac, json, os, re, secrets, sqlite3, time
from contextlib import closing
from datetime import datetime, timedelta, timezone
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Request, Response, UploadFile, File, Depends, Body
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

DATA = Path(os.environ.get("DATA_DIR", "/data"))
FILES = DATA / "files"
DB_PATH = DATA / "zettelfrei.db"
TRIAL_DAYS = int(os.environ.get("TRIAL_DAYS", "30"))
AI_DAILY_LIMIT = int(os.environ.get("AI_DAILY_LIMIT", "80"))
AI_PROVIDER = os.environ.get("AI_PROVIDER", "anthropic").lower()
ANTHROPIC_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
ANTHROPIC_MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5-5")
# Günstigeres Modell für KI-Hilfen (Erklären, Fragen, Antworten); Briefe auslesen nutzt ANTHROPIC_MODEL
ANTHROPIC_HELP_MODEL = os.environ.get("ANTHROPIC_HELP_MODEL", "claude-haiku-5-5")
ANTHROPIC_BASE = os.environ.get("ANTHROPIC_BASE_URL", "https://api.anthropic.com").rstrip("/")
ANTHROPIC_MODELS = {"claude-sonnet-5-5": "Claude Sonnet 5.5 (beste Qualität)", "claude-haiku-5-5": "Claude Haiku 5.5 (sehr günstig)"}
OPENAI_KEY = os.environ.get("OPENAI_API_KEY", "")
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4.1-mini")
GEMINI_KEY = os.environ.get("GEMINI_API_KEY", "")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")
ADMIN_EMAILS = {e.strip().lower() for e in os.environ.get("ADMIN_EMAILS", "").split(",") if e.strip()}
COOKIE = "zf_session"
SECURE_COOKIE = os.environ.get("SECURE_COOKIE", "1") == "1"
COLLECTIONS = {"letters", "members", "settings", "feedback"}
ID_RE = re.compile(r"^[A-Za-z0-9_\-.:@+~]{1,120}$")
MAX_UPLOAD = 20 * 1024 * 1024
ALLOWED_TYPES = {"image/jpeg", "image/png", "image/webp", "image/gif", "application/pdf"}

# KI-Kontingente pro Familie und Monat (im Admin-Bereich änderbar).
# scans = Briefe mit KI auslesen (Foto), helps = Erklären / Frage stellen / Antwort entwerfen.
LIMITS = {
    "trial": {"scans": 30, "helps": 60},
    "family": {"scans": 30, "helps": 60},
    "pro": {"scans": 300, "helps": 600},
}
# Notbremse: höchstens so viele US-Dollar KI-Kosten pro Monat für alle Familien zusammen (0 = aus)
BUDGET_USD = float(os.environ.get("AI_MONTHLY_BUDGET_USD", "25"))
PRICES = {  # US-Dollar je 1 Mio. Tokens (Eingabe, Ausgabe)
    "claude-sonnet-5-5": (2.0, 10.0),
    "claude-haiku-5-5": (0.10, 0.50),
    "gpt-4.1-mini": (0.40, 1.60),
    "gemini-2.5-flash": (0.30, 2.50),
}

DATA.mkdir(parents=True, exist_ok=True)
FILES.mkdir(parents=True, exist_ok=True)
CONFIG = DATA / "config.json"


def load_config():
    global AI_PROVIDER, OPENAI_KEY, GEMINI_KEY, ANTHROPIC_KEY, ANTHROPIC_MODEL, ANTHROPIC_HELP_MODEL, BUDGET_USD
    try:
        cfg = json.loads(CONFIG.read_text())
    except Exception:
        return
    if cfg.get("openai_key"):
        OPENAI_KEY = cfg["openai_key"]
    if cfg.get("gemini_key"):
        GEMINI_KEY = cfg["gemini_key"]
    if cfg.get("anthropic_key"):
        ANTHROPIC_KEY = cfg["anthropic_key"]
    if cfg.get("anthropic_model") in ANTHROPIC_MODELS:
        ANTHROPIC_MODEL = cfg["anthropic_model"]
    if cfg.get("anthropic_help_model") in ANTHROPIC_MODELS:
        ANTHROPIC_HELP_MODEL = cfg["anthropic_help_model"]
    if cfg.get("provider") in ("openai", "gemini", "anthropic"):
        AI_PROVIDER = cfg["provider"]
    lim = cfg.get("limits")
    if isinstance(lim, dict):
        for plan, v in lim.items():
            if plan in LIMITS and isinstance(v, dict):
                for k in ("scans", "helps"):
                    if isinstance(v.get(k), int) and 0 <= v[k] <= 100000:
                        LIMITS[plan][k] = v[k]
    if isinstance(cfg.get("budget_usd"), (int, float)) and 0 <= cfg["budget_usd"] <= 100000:
        BUDGET_USD = float(cfg["budget_usd"])


def save_cfg(update: dict):
    try:
        cfg = json.loads(CONFIG.read_text())
    except Exception:
        cfg = {}
    cfg.update(update)
    CONFIG.write_text(json.dumps(cfg))
    os.chmod(CONFIG, 0o600)
    load_config()


def pick_provider():
    keys = {"anthropic": ANTHROPIC_KEY, "openai": OPENAI_KEY, "gemini": GEMINI_KEY}
    if keys.get(AI_PROVIDER):
        return AI_PROVIDER
    for p in ("anthropic", "openai", "gemini"):
        if keys[p]:
            return p
    return None


load_config()


def now() -> datetime:
    return datetime.now(timezone.utc)


def iso(d: datetime) -> str:
    return d.isoformat(timespec="seconds")


def db() -> sqlite3.Connection:
    c = sqlite3.connect(DB_PATH, timeout=10)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    return c


def init_db():
    with closing(db()) as c, c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS families(
              id TEXT PRIMARY KEY, name TEXT, invite_code TEXT UNIQUE, plan TEXT DEFAULT 'trial',
              trial_ends TEXT, paid_until TEXT, created TEXT);
            CREATE TABLE IF NOT EXISTS users(
              id TEXT PRIMARY KEY, email TEXT UNIQUE, pw_hash TEXT, name TEXT, family_id TEXT REFERENCES families(id),
              role TEXT, member_id TEXT, created TEXT);
            CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id TEXT REFERENCES users(id) ON DELETE CASCADE, expires TEXT);
            CREATE TABLE IF NOT EXISTS docs(
              family_id TEXT, col TEXT, id TEXT, data TEXT, updated TEXT, PRIMARY KEY(family_id, col, id));
            CREATE TABLE IF NOT EXISTS files(
              id TEXT PRIMARY KEY, family_id TEXT, content_type TEXT, size INTEGER, created TEXT);
            CREATE TABLE IF NOT EXISTS ai_usage(family_id TEXT, day TEXT, n INTEGER, PRIMARY KEY(family_id, day));
            CREATE TABLE IF NOT EXISTS login_attempts(key TEXT PRIMARY KEY, n INTEGER, since REAL);
            CREATE TABLE IF NOT EXISTS ai_log(
              id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, month TEXT, family_id TEXT, kind TEXT,
              provider TEXT, model TEXT, in_tok INTEGER, out_tok INTEGER, cost REAL);
            CREATE INDEX IF NOT EXISTS ai_log_fm ON ai_log(family_id, month);
            CREATE TABLE IF NOT EXISTS ai_bonus(
              family_id TEXT, month TEXT, scans INTEGER DEFAULT 0, helps INTEGER DEFAULT 0, PRIMARY KEY(family_id, month));
            """
        )


init_db()
app = FastAPI(title="Mailcut", docs_url=None, redoc_url=None, openapi_url=None)


# ----------------------------------------------------------------- Sicherheit
def hash_pw(pw: str) -> str:
    salt = secrets.token_bytes(16)
    h = hashlib.scrypt(pw.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return base64.b64encode(salt + h).decode()


def check_pw(pw: str, stored: str) -> bool:
    raw = base64.b64decode(stored)
    salt, h = raw[:16], raw[16:]
    h2 = hashlib.scrypt(pw.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return hmac.compare_digest(h, h2)


def token_hash(t: str) -> str:
    return hashlib.sha256(t.encode()).hexdigest()


def rate_limit(key: str, limit: int = 10, window: int = 900):
    with closing(db()) as c, c:
        r = c.execute("SELECT n, since FROM login_attempts WHERE key=?", (key,)).fetchone()
        t = time.time()
        if not r or t - r["since"] > window:
            c.execute("INSERT OR REPLACE INTO login_attempts VALUES(?,?,?)", (key, 1, t))
            return
        if r["n"] >= limit:
            raise HTTPException(429, "Zu viele Versuche. Bitte in 15 Minuten erneut probieren.")
        c.execute("UPDATE login_attempts SET n=n+1 WHERE key=?", (key,))


def new_session(resp: Response, user_id: str):
    t = secrets.token_urlsafe(32)
    with closing(db()) as c, c:
        c.execute("INSERT INTO sessions VALUES(?,?,?)", (token_hash(t), user_id, iso(now() + timedelta(days=60))))
    resp.set_cookie(COOKIE, t, max_age=60 * 86400, httponly=True, secure=SECURE_COOKIE, samesite="lax", path="/")


def current(request: Request) -> dict:
    t = request.cookies.get(COOKIE)
    if not t:
        raise HTTPException(401, "Nicht angemeldet")
    with closing(db()) as c:
        r = c.execute(
            """SELECT u.*, f.name AS family_name, f.invite_code, f.plan, f.trial_ends, f.paid_until
               FROM sessions s JOIN users u ON u.id=s.user_id JOIN families f ON f.id=u.family_id
               WHERE s.token_hash=? AND s.expires>?""",
            (token_hash(t), iso(now())),
        ).fetchone()
    if not r:
        raise HTTPException(401, "Sitzung abgelaufen")
    return dict(r)


def access(u: dict) -> dict:
    """Zugangsstatus: aktiv in Testphase, bezahlt oder abgelaufen."""
    n = now()
    paid = u.get("paid_until") and datetime.fromisoformat(u["paid_until"]) > n
    trial_end = datetime.fromisoformat(u["trial_ends"])
    days_left = max(0, (trial_end - n).days + (1 if (trial_end - n).seconds > 0 else 0))
    active = bool(paid) or trial_end > n
    return {"active": active, "paid": bool(paid), "trialEnds": u["trial_ends"], "trialDaysLeft": days_left, "plan": u["plan"]}


def require_active(u: dict):
    if not access(u)["active"]:
        raise HTTPException(402, "Die Testphase ist abgelaufen.")


def is_admin(u: dict) -> bool:
    return u["email"].lower() in ADMIN_EMAILS


# ------------------------------------------------------------------- Konten
def put_doc(c, fam, col, id_, data):
    c.execute(
        "INSERT OR REPLACE INTO docs VALUES(?,?,?,?,?)",
        (fam, col, id_, json.dumps(data, ensure_ascii=False), iso(now())),
    )


COLORS = ["#1d4ed8", "#be185d", "#7c3aed", "#0f766e", "#c2410c", "#4d7c0f", "#b45309", "#475569"]


def valid_email(e: str) -> bool:
    return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", e)) and len(e) <= 200


@app.post("/api/register")
async def register(request: Request, response: Response):
    b = await request.json()
    email = str(b.get("email", "")).strip().lower()
    pw = str(b.get("password", ""))
    name = str(b.get("name", "")).strip()[:60]
    fam_name = str(b.get("familyName", "")).strip()[:60]
    rate_limit("reg:" + (request.client.host if request.client else "?"), 8, 3600)
    if not valid_email(email) or len(pw) < 8 or not name:
        raise HTTPException(400, "Bitte Name, gültige E-Mail und ein Passwort mit mindestens 8 Zeichen angeben.")
    fid, uid = "f" + secrets.token_hex(8), "u" + secrets.token_hex(8)
    code = secrets.token_hex(3).upper()
    mid = "m" + uid
    with closing(db()) as c, c:
        if c.execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone():
            raise HTTPException(409, "Diese E-Mail ist schon registriert. Bitte anmelden.")
        c.execute(
            "INSERT INTO families VALUES(?,?,?,?,?,?,?)",
            (fid, fam_name or name, code, "trial", iso(now() + timedelta(days=TRIAL_DAYS)), None, iso(now())),
        )
        c.execute("INSERT INTO users VALUES(?,?,?,?,?,?,?,?)", (uid, email, hash_pw(pw), name, fid, "owner", mid, iso(now())))
        put_doc(c, fid, "members", mid, {"name": name, "role": "adult", "color": COLORS[0], "order": 0, "userId": uid})
        put_doc(c, fid, "settings", "main", {"familyName": fam_name})
    new_session(response, uid)
    return {"ok": True}


@app.post("/api/join")
async def join(request: Request, response: Response):
    b = await request.json()
    email = str(b.get("email", "")).strip().lower()
    pw = str(b.get("password", ""))
    name = str(b.get("name", "")).strip()[:60]
    code = str(b.get("code", "")).strip().upper()
    rate_limit("join:" + (request.client.host if request.client else "?"), 10, 3600)
    if not valid_email(email) or len(pw) < 8 or not name or not code:
        raise HTTPException(400, "Bitte Einladungscode, Name, E-Mail und Passwort (mind. 8 Zeichen) angeben.")
    with closing(db()) as c, c:
        f = c.execute("SELECT * FROM families WHERE invite_code=?", (code,)).fetchone()
        if not f:
            raise HTTPException(404, "Einladungscode nicht gefunden.")
        if c.execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone():
            raise HTTPException(409, "Diese E-Mail ist schon registriert. Bitte anmelden.")
        n_users = c.execute("SELECT COUNT(*) FROM users WHERE family_id=?", (f["id"],)).fetchone()[0]
        if n_users >= 6:
            raise HTTPException(403, "Diese Familie hat schon 6 Personen.")
        uid = "u" + secrets.token_hex(8)
        mid = "m" + uid
        c.execute("INSERT INTO users VALUES(?,?,?,?,?,?,?,?)", (uid, email, hash_pw(pw), name, f["id"], "member", mid, iso(now())))
        n_members = c.execute("SELECT COUNT(*) FROM docs WHERE family_id=? AND col='members'", (f["id"],)).fetchone()[0]
        put_doc(c, f["id"], "members", mid, {"name": name, "role": "adult", "color": COLORS[n_members % len(COLORS)], "order": n_members, "userId": uid})
    new_session(response, uid)
    return {"ok": True}


@app.post("/api/login")
async def login(request: Request, response: Response):
    b = await request.json()
    email = str(b.get("email", "")).strip().lower()
    pw = str(b.get("password", ""))
    rate_limit("login:" + email, 10, 900)
    with closing(db()) as c:
        u = c.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    if not u or not check_pw(pw, u["pw_hash"]):
        raise HTTPException(401, "E-Mail oder Passwort falsch.")
    new_session(response, u["id"])
    return {"ok": True}


@app.post("/api/logout")
async def logout(request: Request, response: Response):
    t = request.cookies.get(COOKIE)
    if t:
        with closing(db()) as c, c:
            c.execute("DELETE FROM sessions WHERE token_hash=?", (token_hash(t),))
    response.delete_cookie(COOKIE, path="/")
    return {"ok": True}


@app.get("/api/me")
def me(u: dict = Depends(current)):
    with closing(db()) as c:
        st = ai_status(c, u["family_id"], eff_plan(u))
    return {
        "user": {"id": u["id"], "email": u["email"], "name": u["name"], "role": u["role"], "memberId": u["member_id"], "admin": is_admin(u)},
        "family": {"id": u["family_id"], "name": u["family_name"], "inviteCode": u["invite_code"]},
        "access": access(u),
        "ai": st,
    }


@app.post("/api/password")
async def change_pw(request: Request, u: dict = Depends(current)):
    b = await request.json()
    if not check_pw(str(b.get("old", "")), u["pw_hash"]) or len(str(b.get("new", ""))) < 8:
        raise HTTPException(400, "Altes Passwort falsch oder neues zu kurz.")
    with closing(db()) as c, c:
        c.execute("UPDATE users SET pw_hash=? WHERE id=?", (hash_pw(str(b["new"])), u["id"]))
    return {"ok": True}


@app.delete("/api/account")
def delete_account(response: Response, u: dict = Depends(current)):
    """Konto löschen. Inhaber: ganze Familie mit allen Briefen und Fotos. Mitglied: nur das eigene Konto."""
    import shutil
    with closing(db()) as c, c:
        if u["role"] == "owner":
            fam = u["family_id"]
            c.execute("DELETE FROM docs WHERE family_id=?", (fam,))
            c.execute("DELETE FROM files WHERE family_id=?", (fam,))
            c.execute("DELETE FROM ai_usage WHERE family_id=?", (fam,))
            c.execute("DELETE FROM ai_bonus WHERE family_id=?", (fam,))
            c.execute("DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE family_id=?)", (fam,))
            c.execute("DELETE FROM users WHERE family_id=?", (fam,))
            c.execute("DELETE FROM families WHERE id=?", (fam,))
            shutil.rmtree(FILES / fam, ignore_errors=True)
        else:
            c.execute("DELETE FROM docs WHERE family_id=? AND col='members' AND id=?", (u["family_id"], u["member_id"]))
            c.execute("DELETE FROM sessions WHERE user_id=?", (u["id"],))
            c.execute("DELETE FROM users WHERE id=?", (u["id"],))
    response.delete_cookie(COOKIE, path="/")
    return {"ok": True}


# --------------------------------------------------------------- Dokumente
def check_col(col: str, id_: str | None = None):
    if col not in COLLECTIONS or (id_ is not None and not ID_RE.match(id_)):
        raise HTTPException(400, "Ungültiger Pfad")


@app.get("/api/col/{col}")
def list_col(col: str, u: dict = Depends(current)):
    check_col(col)
    with closing(db()) as c:
        rows = c.execute("SELECT id, data, updated FROM docs WHERE family_id=? AND col=?", (u["family_id"], col)).fetchall()
    return {"docs": [{"id": r["id"], "data": json.loads(r["data"]), "updated": r["updated"]} for r in rows]}


@app.get("/api/doc/{col}/{id_}")
def get_doc(col: str, id_: str, u: dict = Depends(current)):
    check_col(col, id_)
    with closing(db()) as c:
        r = c.execute("SELECT data FROM docs WHERE family_id=? AND col=? AND id=?", (u["family_id"], col, id_)).fetchone()
    return {"exists": bool(r), "data": json.loads(r["data"]) if r else None}


def merge(a: dict, b: dict) -> dict:
    out = dict(a)
    for k, v in b.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = merge(out[k], v)
        else:
            out[k] = v
    return out


@app.put("/api/doc/{col}/{id_}")
async def set_doc(col: str, id_: str, request: Request, u: dict = Depends(current)):
    check_col(col, id_)
    if col != "feedback":
        require_active(u)
    body = await request.body()
    if len(body) > 256 * 1024:
        raise HTTPException(413, "Dokument zu groß")
    data = json.loads(body)
    if not isinstance(data, dict):
        raise HTTPException(400, "Ungültige Daten")
    if col == "feedback":
        data = {"text": str(data.get("text", ""))[:4000], "who": u["name"], "email": u["email"], "family": u["family_name"], "at": iso(now()), "lang": str(data.get("lang", ""))[:5]}
    with closing(db()) as c, c:
        if col == "letters":
            n = c.execute("SELECT COUNT(*) FROM docs WHERE family_id=? AND col='letters'", (u["family_id"],)).fetchone()[0]
            if n >= 5000:
                raise HTTPException(507, "Speicher voll")
        put_doc(c, u["family_id"], col, id_, data)
    return {"ok": True}


@app.patch("/api/doc/{col}/{id_}")
async def update_doc(col: str, id_: str, request: Request, u: dict = Depends(current)):
    check_col(col, id_)
    require_active(u)
    patch = await request.json()
    with closing(db()) as c, c:
        r = c.execute("SELECT data FROM docs WHERE family_id=? AND col=? AND id=?", (u["family_id"], col, id_)).fetchone()
        if not r:
            raise HTTPException(404, "Nicht gefunden")
        put_doc(c, u["family_id"], col, id_, merge(json.loads(r["data"]), patch))
    return {"ok": True}


@app.delete("/api/doc/{col}/{id_}")
def delete_doc(col: str, id_: str, u: dict = Depends(current)):
    check_col(col, id_)
    with closing(db()) as c, c:
        c.execute("DELETE FROM docs WHERE family_id=? AND col=? AND id=?", (u["family_id"], col, id_))
    return {"ok": True}


# ------------------------------------------------------------------ Dateien
@app.post("/api/upload")
async def upload(file: UploadFile = File(...), u: dict = Depends(current)):
    require_active(u)
    ct = (file.content_type or "").split(";")[0]
    if ct not in ALLOWED_TYPES:
        raise HTTPException(415, "Nur Fotos (JPG, PNG, WebP) und PDF")
    data = await file.read(MAX_UPLOAD + 1)
    if len(data) > MAX_UPLOAD:
        raise HTTPException(413, "Datei zu groß (max. 20 MB)")
    fid = "a" + secrets.token_hex(12)
    d = FILES / u["family_id"]
    d.mkdir(parents=True, exist_ok=True)
    (d / fid).write_bytes(data)
    with closing(db()) as c, c:
        c.execute("INSERT INTO files VALUES(?,?,?,?,?)", (fid, u["family_id"], ct, len(data), iso(now())))
    return {"id": fid, "url": "/_blob/" + fid, "sizeBytes": len(data), "contentType": ct}


@app.get("/_blob/{fid}")
def blob(fid: str, u: dict = Depends(current)):
    with closing(db()) as c:
        r = c.execute("SELECT * FROM files WHERE id=? AND family_id=?", (fid, u["family_id"])).fetchone()
    if not r:
        raise HTTPException(404)
    return FileResponse(FILES / u["family_id"] / fid, media_type=r["content_type"], headers={"Cache-Control": "private, max-age=86400"})


@app.delete("/api/upload/{fid}")
def delete_file(fid: str, u: dict = Depends(current)):
    with closing(db()) as c, c:
        r = c.execute("SELECT 1 FROM files WHERE id=? AND family_id=?", (fid, u["family_id"])).fetchone()
        if r:
            c.execute("DELETE FROM files WHERE id=?", (fid,))
            (FILES / u["family_id"] / fid).unlink(missing_ok=True)
    return {"ok": True}


# ----------------------------------------------------------------------- KI
def month_key() -> str:
    return now().strftime("%Y-%m")


def next_month_start() -> str:
    n = now()
    y, m = (n.year + 1, 1) if n.month == 12 else (n.year, n.month + 1)
    return f"{y:04d}-{m:02d}-01"


def eff_plan(row: dict) -> str:
    """Welcher Tarif für die KI-Kontingente gilt: trial, family oder pro."""
    if row.get("plan") == "pro":
        return "pro"
    paid = row.get("paid_until") and datetime.fromisoformat(row["paid_until"]) > now()
    return "family" if (paid or row.get("plan") == "family") else "trial"


def ai_status(c, fam: str, plan: str) -> dict:
    """Verbrauch und Grenzen einer Familie im laufenden Monat."""
    mon = month_key()
    used = {r["kind"]: r["n"] for r in c.execute(
        "SELECT kind, COUNT(*) AS n FROM ai_log WHERE family_id=? AND month=? GROUP BY kind", (fam, mon))}
    b = c.execute("SELECT scans, helps FROM ai_bonus WHERE family_id=? AND month=?", (fam, mon)).fetchone()
    lim = LIMITS.get(plan) or LIMITS["family"]
    return {
        "plan": plan, "month": mon, "resets": next_month_start(),
        "scans": {"used": used.get("scan", 0), "limit": max(0, lim["scans"] + (b["scans"] if b else 0))},
        "helps": {"used": used.get("help", 0), "limit": max(0, lim["helps"] + (b["helps"] if b else 0))},
    }


def month_cost(c) -> float:
    return float(c.execute("SELECT COALESCE(SUM(cost), 0) AS s FROM ai_log WHERE month=?", (month_key(),)).fetchone()["s"])


def ai_cost(model: str, tin: int, tout: int) -> float:
    pin, pout = PRICES.get(model, (2.0, 10.0))
    if model == "claude-haiku-5-5" and tin > 100_000:
        pin, pout = 0.50, 2.50
    return (tin * pin + tout * pout) / 1_000_000


def log_ai(fam: str, kind: str, provider: str, model: str, tin: int, tout: int):
    with closing(db()) as c, c:
        c.execute(
            "INSERT INTO ai_log(ts, month, family_id, kind, provider, model, in_tok, out_tok, cost) VALUES(?,?,?,?,?,?,?,?,?)",
            (iso(now()), month_key(), fam, kind, provider, model, tin, tout, ai_cost(model, tin, tout)),
        )


def count_ai(fam: str):
    """Zusätzliche Bremse gegen sehr viele Aufrufe an einem Tag."""
    day = now().strftime("%Y-%m-%d")
    with closing(db()) as c, c:
        r = c.execute("SELECT n FROM ai_usage WHERE family_id=? AND day=?", (fam, day)).fetchone()
        if r and r["n"] >= AI_DAILY_LIMIT:
            raise HTTPException(429, {"code": "quota_day"})
        c.execute("INSERT INTO ai_usage VALUES(?,?,1) ON CONFLICT(family_id,day) DO UPDATE SET n=n+1", (fam, day))


async def call_openai(prompt: str, images: list[dict], want_json: bool):
    content = [{"type": "text", "text": prompt}] + [
        {"type": "image_url", "image_url": {"url": f"data:{i['type']};base64,{i['data']}", "detail": "high"}} for i in images
    ]
    body = {"model": OPENAI_MODEL, "messages": [{"role": "user", "content": content}], "temperature": 0.2}
    if want_json:
        body["response_format"] = {"type": "json_object"}
    async with httpx.AsyncClient(timeout=120) as cl:
        r = await cl.post("https://api.openai.com/v1/chat/completions", json=body, headers={"Authorization": f"Bearer {OPENAI_KEY}"})
    if r.status_code != 200:
        raise HTTPException(502, "KI-Dienst nicht erreichbar")
    j = r.json()
    us = j.get("usage") or {}
    return j["choices"][0]["message"]["content"], int(us.get("prompt_tokens") or 0), int(us.get("completion_tokens") or 0), OPENAI_MODEL


async def call_gemini(prompt: str, images: list[dict], want_json: bool):
    parts = [{"text": prompt}] + [{"inline_data": {"mime_type": i["type"], "data": i["data"]}} for i in images]
    body = {"contents": [{"role": "user", "parts": parts}], "generationConfig": {"temperature": 0.2}}
    if want_json:
        body["generationConfig"]["responseMimeType"] = "application/json"
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent"
    async with httpx.AsyncClient(timeout=120) as cl:
        r = await cl.post(url, json=body, headers={"x-goog-api-key": GEMINI_KEY})
    if r.status_code != 200:
        raise HTTPException(502, "KI-Dienst nicht erreichbar")
    j = r.json()
    cand = j.get("candidates") or []
    um = j.get("usageMetadata") or {}
    text = "".join(p.get("text", "") for p in (cand[0]["content"]["parts"] if cand else []))
    tout = int(um.get("candidatesTokenCount") or 0) + int(um.get("thoughtsTokenCount") or 0)
    return text, int(um.get("promptTokenCount") or 0), tout, GEMINI_MODEL


async def call_anthropic(prompt: str, images: list[dict], want_json: bool, model: str = ""):
    content = [{"type": "image", "source": {"type": "base64", "media_type": i["type"], "data": i["data"]}} for i in images]
    text = prompt
    if want_json:
        text += "\n\nAntworte ausschließlich mit dem JSON-Objekt, ohne Erklärung und ohne Markdown."
    content.append({"type": "text", "text": text})
    model = model or ANTHROPIC_MODEL
    body = {"model": model, "max_tokens": 4096, "messages": [{"role": "user", "content": content}]}
    headers = {"x-api-key": ANTHROPIC_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"}
    async with httpx.AsyncClient(timeout=180) as cl:
        r = await cl.post(f"{ANTHROPIC_BASE}/v1/messages", json=body, headers=headers)
    if r.status_code == 429:
        raise HTTPException(429, "Die KI ist gerade ausgelastet. Bitte gleich nochmal versuchen.")
    if r.status_code != 200:
        detail = ""
        try:
            detail = r.json().get("error", {}).get("message", "")
        except Exception:
            pass
        print(f"[KI] Claude-Fehler {r.status_code}: {detail[:300]}", flush=True)
        if "credit balance" in detail.lower():
            raise HTTPException(503, "KI vorübergehend nicht verfügbar (Guthaben beim KI-Anbieter leer).")
        raise HTTPException(502, "KI-Dienst nicht erreichbar")
    data = r.json()
    us = data.get("usage") or {}
    tin = int(us.get("input_tokens") or 0) + int(us.get("cache_creation_input_tokens") or 0) + int(us.get("cache_read_input_tokens") or 0)
    text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
    return text, tin, int(us.get("output_tokens") or 0), model


@app.post("/api/ai")
async def ai(request: Request, u: dict = Depends(current)):
    require_active(u)
    b = await request.json()
    prompt = str(b.get("prompt", ""))[:60000]
    images = b.get("images") or []
    if not prompt or len(images) > 8:
        raise HTTPException(400, "Ungültige Anfrage")
    imgs = []
    for i in images:
        t = str(i.get("type", ""))
        d = str(i.get("data", ""))
        if t not in {"image/jpeg", "image/png", "image/webp"} or len(d) > 12_000_000:
            raise HTTPException(415, "Bildformat nicht unterstützt")
        imgs.append({"type": t, "data": d})
    if AI_PROVIDER != "mock" and not pick_provider():
        raise HTTPException(503, "KI ist auf dem Server noch nicht eingerichtet.")
    # Monatskontingent der Familie und Notbremse prüfen (fehlgeschlagene Aufrufe zählen nicht)
    kind = "scan" if imgs else "help"
    plan = eff_plan(u)
    with closing(db()) as c:
        st = ai_status(c, u["family_id"], plan)
        spent = month_cost(c)
    q = st["scans" if kind == "scan" else "helps"]
    if q["used"] >= q["limit"]:
        raise HTTPException(429, {"code": f"quota_{kind}s", "limit": q["limit"], "resets": st["resets"]})
    if BUDGET_USD > 0 and spent >= BUDGET_USD:
        print(f"[KI] Monatsbudget von {BUDGET_USD} $ erreicht – KI pausiert", flush=True)
        raise HTTPException(429, {"code": "budget"})
    count_ai(u["family_id"])
    want_json = bool(b.get("json"))
    if AI_PROVIDER == "mock":  # nur fuer lokale Tests
        text = json.dumps({"betreff": "Testbrief", "absender": "Test GmbH", "kategorie": "rechnung", "zusammenfassung": "Testantwort.", "aufgaben": ["Pruefen"], "frist": {"datum": None}}) if want_json else "Testantwort der KI."
        prov, tin, tout, model = "mock", 0, 0, "mock"
    else:
        prov = pick_provider()
        if prov == "anthropic":
            text, tin, tout, model = await call_anthropic(prompt, imgs, want_json, ANTHROPIC_MODEL if kind == "scan" else ANTHROPIC_HELP_MODEL)
        elif prov == "openai":
            text, tin, tout, model = await call_openai(prompt, imgs, want_json)
        elif prov == "gemini":
            text, tin, tout, model = await call_gemini(prompt, imgs, want_json)
        else:
            raise HTTPException(503, "KI ist auf dem Server noch nicht eingerichtet.")
    log_ai(u["family_id"], kind, prov, model, tin, tout)
    with closing(db()) as c:
        st = ai_status(c, u["family_id"], plan)
    return {"text": text, "usage": st}


# ------------------------------------------------------------------- Admin
def admin_only(u: dict = Depends(current)):
    if not is_admin(u):
        raise HTTPException(403)
    return u


@app.get("/api/admin/overview")
def admin_overview(u: dict = Depends(admin_only)):
    with closing(db()) as c:
        fams = [dict(r) for r in c.execute(
            """SELECT f.*, (SELECT COUNT(*) FROM users WHERE family_id=f.id) AS users,
               (SELECT COUNT(*) FROM docs WHERE family_id=f.id AND col='letters') AS letters,
               (SELECT GROUP_CONCAT(email, ', ') FROM users WHERE family_id=f.id) AS emails,
               (SELECT COALESCE(SUM(cost), 0) FROM ai_log WHERE family_id=f.id AND month=?) AS ai_cost
               FROM families f ORDER BY created DESC""", (month_key(),)
        ).fetchall()]
        for f in fams:
            f["ai"] = ai_status(c, f["id"], eff_plan(f))
        fb = c.execute("SELECT data FROM docs WHERE col='feedback' ORDER BY updated DESC LIMIT 300").fetchall()
    return {"families": fams, "feedback": [json.loads(r["data"]) for r in fb]}


@app.post("/api/admin/family/{fid}")
async def admin_family(fid: str, request: Request, u: dict = Depends(admin_only)):
    b = await request.json()
    with closing(db()) as c, c:
        if "plan" in b and b["plan"] in {"trial", "family", "pro"}:
            c.execute("UPDATE families SET plan=? WHERE id=?", (b["plan"], fid))
        if "extendDays" in b:
            c.execute("UPDATE families SET trial_ends=? WHERE id=?", (iso(now() + timedelta(days=int(b["extendDays"]))), fid))
        if "paidMonths" in b:
            c.execute("UPDATE families SET paid_until=? WHERE id=?", (iso(now() + timedelta(days=31 * int(b["paidMonths"]))), fid))
        for key, col in (("bonusScans", "scans"), ("bonusHelps", "helps")):
            if key in b:
                n = int(b[key])
                if not -1000 <= n <= 1000:
                    raise HTTPException(400, "Bonus außerhalb des erlaubten Bereichs.")
                c.execute(
                    f"INSERT INTO ai_bonus(family_id, month, {col}) VALUES(?,?,?) "
                    f"ON CONFLICT(family_id, month) DO UPDATE SET {col}={col}+excluded.{col}",
                    (fid, month_key(), n),
                )
    return {"ok": True}


@app.get("/api/admin/limits")
def admin_limits_get(u: dict = Depends(admin_only)):
    with closing(db()) as c:
        spent = month_cost(c)
        tot = {r["kind"]: r["n"] for r in c.execute(
            "SELECT kind, COUNT(*) AS n FROM ai_log WHERE month=? GROUP BY kind", (month_key(),))}
    return {"limits": LIMITS, "budgetUsd": BUDGET_USD, "month": month_key(), "spentUsd": round(spent, 4),
            "scans": tot.get("scan", 0), "helps": tot.get("help", 0)}


@app.post("/api/admin/limits")
async def admin_limits_set(request: Request, u: dict = Depends(admin_only)):
    b = await request.json()
    lim = {}
    for plan in ("trial", "family", "pro"):
        v = (b.get("limits") or {}).get(plan) or {}
        lim[plan] = {}
        for k in ("scans", "helps"):
            try:
                n = int(v.get(k, LIMITS[plan][k]))
            except (TypeError, ValueError):
                raise HTTPException(400, "Bitte nur ganze Zahlen eintragen.")
            if not 0 <= n <= 100000:
                raise HTTPException(400, "Zahl außerhalb des erlaubten Bereichs.")
            lim[plan][k] = n
    upd = {"limits": lim}
    if "budgetUsd" in b:
        try:
            bud = float(str(b["budgetUsd"]).replace(",", "."))
        except (TypeError, ValueError):
            raise HTTPException(400, "Budget bitte als Zahl eintragen.")
        if not 0 <= bud <= 100000:
            raise HTTPException(400, "Budget außerhalb des erlaubten Bereichs.")
        upd["budget_usd"] = bud
    save_cfg(upd)
    return {"ok": True, "limits": LIMITS, "budgetUsd": BUDGET_USD}


@app.get("/api/admin/ai")
def admin_ai_status(u: dict = Depends(admin_only)):
    def mask(k):
        return (k[:7] + "…" + k[-4:]) if k else ""
    prov = pick_provider()
    model = {"anthropic": ANTHROPIC_MODEL, "openai": OPENAI_MODEL, "gemini": GEMINI_MODEL}.get(prov or "", "")
    return {"provider": prov, "model": model, "helpModel": ANTHROPIC_HELP_MODEL, "models": ANTHROPIC_MODELS,
            "keys": {"anthropic": mask(ANTHROPIC_KEY), "openai": mask(OPENAI_KEY), "gemini": mask(GEMINI_KEY)}}


@app.post("/api/admin/ai")
async def admin_ai_set(request: Request, u: dict = Depends(admin_only)):
    b = await request.json()
    key = str(b.get("key", "")).strip()
    model = str(b.get("model", "")).strip()
    help_model = str(b.get("helpModel", "")).strip()
    try:
        cfg = json.loads(CONFIG.read_text())
    except Exception:
        cfg = {}
    if help_model in ANTHROPIC_MODELS:
        cfg["anthropic_help_model"] = help_model
    if not key:
        # nur Modelle wechseln
        if model in ANTHROPIC_MODELS or help_model in ANTHROPIC_MODELS:
            if model in ANTHROPIC_MODELS:
                cfg["anthropic_model"] = model
            CONFIG.write_text(json.dumps(cfg)); os.chmod(CONFIG, 0o600); load_config()
            return {"ok": True, "provider": pick_provider(), "model": ANTHROPIC_MODEL, "helpModel": ANTHROPIC_HELP_MODEL}
        raise HTTPException(400, "Bitte einen Schlüssel einfügen.")
    if key.startswith("sk-ant-"):
        prov, field = "anthropic", "anthropic_key"
    elif key.startswith("sk-"):
        prov, field = "openai", "openai_key"
    elif key.startswith("AIza"):
        prov, field = "gemini", "gemini_key"
    else:
        raise HTTPException(400, "Unbekanntes Format. Claude-Schlüssel beginnen mit sk-ant-, OpenAI mit sk-, Gemini mit AIza.")
    # Schlüssel beim Anbieter prüfen, bevor er gespeichert wird
    async with httpx.AsyncClient(timeout=20) as cl:
        if prov == "anthropic":
            r = await cl.get(f"{ANTHROPIC_BASE}/v1/models", headers={"x-api-key": key, "anthropic-version": "2023-06-01"})
        elif prov == "openai":
            r = await cl.get("https://api.openai.com/v1/models", headers={"Authorization": f"Bearer {key}"})
        else:
            r = await cl.get("https://generativelanguage.googleapis.com/v1beta/models", headers={"x-goog-api-key": key})
    if r.status_code != 200:
        raise HTTPException(400, "Der Schlüssel wurde vom Anbieter abgelehnt. Bitte prüfen.")
    cfg[field] = key
    cfg["provider"] = prov
    if prov == "anthropic" and model in ANTHROPIC_MODELS:
        cfg["anthropic_model"] = model
    CONFIG.write_text(json.dumps(cfg))
    os.chmod(CONFIG, 0o600)
    load_config()
    return {"ok": True, "provider": prov, "model": ANTHROPIC_MODEL if prov == "anthropic" else ""}


@app.get("/api/health")
def health():
    return {"ok": True, "ai": bool(pick_provider())}



# ------------------------------------------------------------- E-Mail-Postfach
# Verbindung zum eigenen Postfach per IMAP/SMTP mit App-Passwort (Gmail, GMX, WEB.DE, T-Online …).
# Gilt nur für die eigene Person (nicht für die Familie). Das App-Passwort liegt verschlüsselt in der
# Datenbank. E-Mails werden nur beim Abruf gelesen (nur lesend), nicht auf dem Server gespeichert.
import email as _email
import email.policy as _epolicy
import email.utils as _eutils
import html as _html
import imaplib
import smtplib
import ssl
from email.header import decode_header, make_header
from email.message import EmailMessage

from cryptography.fernet import Fernet, InvalidToken

MAIL_DAILY_LIMIT = int(os.environ.get("MAIL_DAILY_LIMIT", "30"))
MAIL_PROVIDERS = {
    "gmail": {"name": "Gmail", "domains": ["gmail.com", "googlemail.com"],
              "imap": ("imap.gmail.com", 993, "ssl"), "smtp": ("smtp.gmail.com", 465, "ssl"), "autosent": True},
    "gmx": {"name": "GMX", "domains": ["gmx.de", "gmx.net", "gmx.at", "gmx.ch", "gmx.eu", "gmx.info", "gmx.org"],
            "imap": ("imap.gmx.net", 993, "ssl"), "smtp": ("mail.gmx.net", 465, "ssl")},
    "webde": {"name": "WEB.DE", "domains": ["web.de"],
              "imap": ("imap.web.de", 993, "ssl"), "smtp": ("smtp.web.de", 587, "starttls")},
    "tonline": {"name": "Telekom (T-Online)", "domains": ["t-online.de", "magenta.de"],
                "imap": ("secureimap.t-online.de", 993, "ssl"), "smtp": ("securesmtp.t-online.de", 465, "ssl")},
    "yahoo": {"name": "Yahoo", "domains": ["yahoo.com", "yahoo.de", "ymail.com", "rocketmail.com"],
              "imap": ("imap.mail.yahoo.com", 993, "ssl"), "smtp": ("smtp.mail.yahoo.com", 465, "ssl")},
    "icloud": {"name": "iCloud", "domains": ["icloud.com", "me.com", "mac.com"],
               "imap": ("imap.mail.me.com", 993, "ssl"), "smtp": ("smtp.mail.me.com", 587, "starttls"), "imap_user": "local"},
    "freenet": {"name": "freenet", "domains": ["freenet.de"],
                "imap": ("mx.freenet.de", 993, "ssl"), "smtp": ("mx.freenet.de", 465, "ssl")},
    "vodafone": {"name": "Vodafone / Arcor", "domains": ["vodafonemail.de", "arcor.de", "vodafone.de"],
                 "imap": ("imap.vodafonemail.de", 993, "ssl"), "smtp": ("smtp.vodafonemail.de", 465, "ssl")},
    "mailde": {"name": "mail.de", "domains": ["mail.de"],
               "imap": ("imap.mail.de", 993, "ssl"), "smtp": ("smtp.mail.de", 465, "ssl")},
    "posteo": {"name": "Posteo", "domains": ["posteo.de", "posteo.net"],
               "imap": ("posteo.de", 993, "ssl"), "smtp": ("posteo.de", 465, "ssl")},
    "ionos": {"name": "IONOS (eigene Domain)", "domains": [],
              "imap": ("imap.ionos.de", 993, "ssl"), "smtp": ("smtp.ionos.de", 465, "ssl")},
    "strato": {"name": "STRATO (eigene Domain)", "domains": [],
               "imap": ("imap.strato.de", 993, "ssl"), "smtp": ("smtp.strato.de", 465, "ssl")},
}
# Microsoft erlaubt seit September 2024 keine App-Passwörter mehr (nur Microsoft-Anmeldung)
MAIL_UNSUPPORTED = {"outlook.com", "outlook.de", "hotmail.com", "hotmail.de", "live.com", "live.de", "msn.com", "windowslive.com"}
if os.environ.get("MAIL_TEST") == "1":  # nur für lokale Tests mit einem Test-Mailserver
    MAIL_PROVIDERS["test"] = {"name": "Testserver", "domains": ["example.test"],
                              "imap": ("127.0.0.1", int(os.environ.get("MAIL_TEST_IMAP", "1143")), "plain"),
                              "smtp": ("127.0.0.1", int(os.environ.get("MAIL_TEST_SMTP", "1025")), "plain")}


def init_mail_db():
    with closing(db()) as c, c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS mail_accounts(
              user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, email TEXT, provider TEXT,
              secret TEXT, sent_folder TEXT, created TEXT, last_ok TEXT);
            CREATE TABLE IF NOT EXISTS mail_log(
              id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, day TEXT, user_id TEXT REFERENCES users(id) ON DELETE CASCADE);
            CREATE INDEX IF NOT EXISTS mail_log_ud ON mail_log(user_id, day);
            """
        )


init_mail_db()


def _mail_fernet() -> Fernet:
    secret = os.environ.get("MAIL_SECRET", "").strip()
    if not secret:  # Ersatz, falls MAIL_SECRET in .env fehlt
        p = DATA / "mail.secret"
        if not p.exists():
            p.write_text(secrets.token_urlsafe(32))
            os.chmod(p, 0o600)
        secret = p.read_text().strip()
    return Fernet(base64.urlsafe_b64encode(hashlib.sha256(secret.encode()).digest()))


def _hdr(v) -> str:
    if not v:
        return ""
    try:
        return str(make_header(decode_header(str(v)))).strip()
    except Exception:
        return str(v).strip()


def _mail_provider_for(addr: str, pid: str = "") -> str:
    dom = addr.rsplit("@", 1)[-1].lower()
    if dom in MAIL_UNSUPPORTED:
        raise HTTPException(400, "mail:outlook")
    if pid:
        if pid not in MAIL_PROVIDERS:
            raise HTTPException(400, "mail:unknown")
        return pid
    for k, p in MAIL_PROVIDERS.items():
        if dom in p["domains"]:
            return k
    raise HTTPException(400, "mail:unknown")


def _imap_open(pid: str, addr: str, pw: str):
    p = MAIL_PROVIDERS[pid]
    host, port, mode = p["imap"]
    users = [addr.split("@")[0], addr] if p.get("imap_user") == "local" else [addr]
    for usr in users:
        try:
            if mode == "ssl":
                m = imaplib.IMAP4_SSL(host, port, ssl_context=ssl.create_default_context(), timeout=20)
            else:
                m = imaplib.IMAP4(host, port, timeout=20)
        except (OSError, imaplib.IMAP4.error):
            raise HTTPException(502, "mail:network")
        try:
            m.login(usr, pw)
            return m
        except imaplib.IMAP4.error:
            _imap_close(m)
        except OSError:
            _imap_close(m)
            raise HTTPException(502, "mail:network")
    raise HTTPException(400, "mail:auth")


def _imap_close(m):
    try:
        m.logout()
    except Exception:
        pass


def _imap_quote(name: str) -> str:
    return '"' + name.replace("\\", "\\\\").replace('"', '\\"') + '"'


_LIST_RE = re.compile(r'^\((?P<flags>[^)]*)\)\s+(?:"(?:[^"\\]|\\.)*"|NIL)\s+(?P<name>.+)$')


def _imap_sent_folder(m) -> str:
    try:
        typ, data = m.list()
    except Exception:
        return ""
    if typ != "OK":
        return ""
    names = []
    for raw in data or []:
        if not isinstance(raw, bytes):
            continue
        mt = _LIST_RE.match(raw.decode("utf-8", "replace").strip())
        if not mt:
            continue
        name = mt.group("name").strip()
        if len(name) >= 2 and name[0] == '"' and name[-1] == '"':
            name = name[1:-1].replace('\\"', '"').replace("\\\\", "\\")
        if "\\sent" in mt.group("flags").lower():
            return name
        names.append(name)
    for cand in ("Gesendet", "Sent", "Gesendete Objekte", "Gesendete Elemente", "Gesendete E-Mails",
                 "Sent Items", "Sent Messages", "INBOX.Sent", "INBOX.Gesendet"):
        for n in names:
            if n.lower() == cand.lower():
                return n
    return ""


def _smtp_open(pid: str, addr: str, pw: str):
    host, port, mode = MAIL_PROVIDERS[pid]["smtp"]
    try:
        if mode == "ssl":
            s = smtplib.SMTP_SSL(host, port, context=ssl.create_default_context(), timeout=25)
        else:
            s = smtplib.SMTP(host, port, timeout=25)
            s.ehlo()
            if mode == "starttls":
                s.starttls(context=ssl.create_default_context())
                s.ehlo()
    except (OSError, smtplib.SMTPException):
        raise HTTPException(502, "mail:network")
    try:
        s.login(addr, pw)
        return s
    except smtplib.SMTPAuthenticationError:
        _smtp_close(s)
        raise HTTPException(400, "mail:smtpauth")
    except (OSError, smtplib.SMTPException):
        _smtp_close(s)
        raise HTTPException(502, "mail:smtp")


def _smtp_close(s):
    try:
        s.quit()
    except Exception:
        pass


def _mail_account(u: dict) -> dict:
    with closing(db()) as c:
        r = c.execute("SELECT * FROM mail_accounts WHERE user_id=?", (u["id"],)).fetchone()
    if not r or r["provider"] not in MAIL_PROVIDERS:
        raise HTTPException(404, "mail:none")
    try:
        pw = _mail_fernet().decrypt(r["secret"].encode()).decode()
    except (InvalidToken, ValueError):
        raise HTTPException(409, "mail:reconnect")
    return {**dict(r), "pw": pw}


def _mail_status(u: dict) -> dict:
    with closing(db()) as c:
        r = c.execute("SELECT email, provider FROM mail_accounts WHERE user_id=?", (u["id"],)).fetchone()
    on = bool(r) and r["provider"] in MAIL_PROVIDERS
    return {
        "connected": on, "email": r["email"] if on else "", "provider": r["provider"] if on else "",
        "providerName": MAIL_PROVIDERS[r["provider"]]["name"] if on else "",
        "providers": [{"id": k, "name": p["name"], "domains": p["domains"]} for k, p in MAIL_PROVIDERS.items()],
        "unsupported": sorted(MAIL_UNSUPPORTED), "dailyLimit": MAIL_DAILY_LIMIT,
    }


def _display_name(u: dict) -> str:
    name, fam = (u.get("name") or "").strip(), (u.get("family_name") or "").strip()
    return name if not fam or fam.lower() in name.lower() else f"{name} {fam}"


def _mail_date(msg, meta: str = "") -> str:
    try:
        d = _eutils.parsedate_to_datetime(msg.get("Date"))
        if d:
            return d.isoformat()
    except Exception:
        pass
    try:
        t = imaplib.Internaldate2tuple(meta.encode())
        if t:
            return datetime.fromtimestamp(time.mktime(t), timezone.utc).isoformat()
    except Exception:
        pass
    return ""


def _html_to_text(h: str) -> str:
    h = re.sub(r"(?is)<(script|style|head)[^>]*>.*?</\1>", " ", h)
    h = re.sub(r"(?i)<br\s*/?>", "\n", h)
    h = re.sub(r"(?i)</(p|div|tr|li|h[1-6]|table|blockquote)>", "\n", h)
    h = re.sub(r"(?i)<li[^>]*>", "• ", h)
    h = re.sub(r"<[^>]+>", " ", h)
    h = _html.unescape(h)
    h = re.sub(r"[ \t\xa0]+", " ", h)
    return re.sub(r" *\n *", "\n", h)


def _mail_text(msg) -> str:
    try:
        part = msg.get_body(preferencelist=("plain", "html"))
    except Exception:
        part = None
    if part is None:
        return ""
    try:
        content = part.get_content()
    except Exception:
        raw = part.get_payload(decode=True) or b""
        content = raw.decode(part.get_content_charset() or "utf-8", "replace")
    if not isinstance(content, str):
        return ""
    if part.get_content_type() == "text/html":
        content = _html_to_text(content)
    return re.sub(r"\n{3,}", "\n\n", content.replace("\r\n", "\n")).strip()


def _addr_list(v) -> list:
    items = v if isinstance(v, list) else re.split(r"[,;]", str(v or ""))
    out = []
    for a in items:
        a = str(a).strip()
        if a:
            if not valid_email(a):
                raise HTTPException(400, "mail:to")
            out.append(a)
    return out


@app.get("/api/mail")
def mail_status(u: dict = Depends(current)):
    return _mail_status(u)


@app.post("/api/mail/connect")
def mail_connect(b: dict = Body(...), u: dict = Depends(current)):
    require_active(u)
    rate_limit("mailconn:" + u["id"], 8, 900)
    addr = str(b.get("email", "")).strip().lower()
    pw = str(b.get("password", "")).strip()
    if not valid_email(addr) or not pw or len(pw) > 200:
        raise HTTPException(400, "mail:input")
    pid = _mail_provider_for(addr, str(b.get("provider") or ""))
    if pid == "gmail":  # Google zeigt App-Passwörter mit Leerzeichen an
        pw = re.sub(r"\s+", "", pw)
    m = _imap_open(pid, addr, pw)
    try:
        sent = "" if MAIL_PROVIDERS[pid].get("autosent") else _imap_sent_folder(m)
    finally:
        _imap_close(m)
    _smtp_close(_smtp_open(pid, addr, pw))
    enc = _mail_fernet().encrypt(pw.encode()).decode()
    with closing(db()) as c, c:
        c.execute("INSERT OR REPLACE INTO mail_accounts VALUES(?,?,?,?,?,?,?)", (u["id"], addr, pid, enc, sent, iso(now()), iso(now())))
    return _mail_status(u)


@app.delete("/api/mail")
def mail_disconnect(u: dict = Depends(current)):
    with closing(db()) as c, c:
        c.execute("DELETE FROM mail_accounts WHERE user_id=?", (u["id"],))
    return _mail_status(u)


@app.get("/api/mail/inbox")
def mail_inbox(n: int = 30, u: dict = Depends(current)):
    require_active(u)
    acc = _mail_account(u)
    m = _imap_open(acc["provider"], acc["email"], acc["pw"])
    try:
        typ, _ = m.select("INBOX", readonly=True)
        if typ != "OK":
            raise HTTPException(502, "mail:imap")
        typ, data = m.uid("search", None, "ALL")
        uids = (data[0] or b"").split() if typ == "OK" and data else []
        uids = uids[-max(1, min(int(n), 50)):]
        items = []
        if uids:
            typ, data = m.uid("fetch", b",".join(uids).decode(), "(UID FLAGS INTERNALDATE BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])")
            data = data or []
            for i, part in enumerate(data):
                if not isinstance(part, tuple):
                    continue
                meta = part[0].decode("utf-8", "replace")
                if i + 1 < len(data) and isinstance(data[i + 1], bytes):
                    meta += data[i + 1].decode("utf-8", "replace")
                mu = re.search(r"UID (\d+)", meta)
                fl = re.search(r"FLAGS \(([^)]*)\)", meta)
                msg = _email.message_from_bytes(part[1] or b"", policy=_epolicy.compat32)
                name, a = _eutils.parseaddr(_hdr(msg.get("From")))
                if mu:
                    items.append({"uid": mu.group(1), "from": name or a, "fromEmail": a, "subject": _hdr(msg.get("Subject"))[:300],
                                  "date": _mail_date(msg, meta), "seen": bool(fl and "\\seen" in fl.group(1).lower())})
        items.sort(key=lambda x: int(x["uid"]), reverse=True)
        with closing(db()) as c, c:
            c.execute("UPDATE mail_accounts SET last_ok=? WHERE user_id=?", (iso(now()), u["id"]))
        return {"items": items, "email": acc["email"]}
    finally:
        _imap_close(m)


@app.get("/api/mail/msg/{uid}")
def mail_message(uid: str, u: dict = Depends(current)):
    require_active(u)
    if not uid.isdigit():
        raise HTTPException(400, "mail:input")
    acc = _mail_account(u)
    m = _imap_open(acc["provider"], acc["email"], acc["pw"])
    try:
        typ, _ = m.select("INBOX", readonly=True)
        if typ != "OK":
            raise HTTPException(502, "mail:imap")
        typ, data = m.uid("fetch", uid, "(RFC822.SIZE)")
        sz = re.search(rb"RFC822\.SIZE (\d+)", b" ".join(x for x in (data or []) if isinstance(x, bytes)))
        if not sz:
            raise HTTPException(404, "mail:gone")
        big = int(sz.group(1)) > 15 * 1024 * 1024
        typ, data = m.uid("fetch", uid, "(BODY.PEEK[HEADER])" if big else "(BODY.PEEK[])")
        raw = next((p[1] for p in (data or []) if isinstance(p, tuple)), None)
        if raw is None:
            raise HTTPException(404, "mail:gone")
        msg = _email.message_from_bytes(raw, policy=_epolicy.default)
        name, a = _eutils.parseaddr(_hdr(msg.get("From")))
        _, rt = _eutils.parseaddr(_hdr(msg.get("Reply-To")))
        atts = [] if big else [(p.get_filename() or "Anhang")[:120] for p in msg.iter_attachments()][:20]
        return {
            "uid": uid, "from": name or a, "fromEmail": a, "replyTo": rt or a, "to": _hdr(msg.get("To"))[:500],
            "subject": _hdr(msg.get("Subject"))[:300], "date": _mail_date(msg),
            "messageId": " ".join(re.findall(r"<[^<>\s]+>", str(msg.get("Message-ID") or "")))[:300],
            "references": " ".join(re.findall(r"<[^<>\s]+>", str(msg.get("References") or "")))[-2000:],
            "text": ("(Diese E-Mail ist sehr groß – bitte im E-Mail-Programm öffnen.)" if big else _mail_text(msg))[:40000],
            "attachments": atts,
        }
    finally:
        _imap_close(m)


@app.post("/api/mail/send")
def mail_send(b: dict = Body(...), u: dict = Depends(current)):
    require_active(u)
    acc = _mail_account(u)
    to, cc = _addr_list(b.get("to")), _addr_list(b.get("cc"))
    if not to or len(to) + len(cc) > 10:
        raise HTTPException(400, "mail:to")
    subject = re.sub(r"[\r\n]+", " ", str(b.get("subject", ""))).strip()[:300]
    body = str(b.get("body", ""))[:60000]
    if not body.strip():
        raise HTTPException(400, "mail:empty")
    day = now().date().isoformat()
    with closing(db()) as c:
        sent_today = c.execute("SELECT COUNT(*) FROM mail_log WHERE user_id=? AND day=?", (u["id"], day)).fetchone()[0]
    if sent_today >= MAIL_DAILY_LIMIT:
        raise HTTPException(429, "mail:limit")
    msg = EmailMessage()
    msg["From"] = _eutils.formataddr((_display_name(u), acc["email"]))
    msg["To"] = ", ".join(to)
    if cc:
        msg["Cc"] = ", ".join(cc)
    msg["Subject"] = subject
    msg["Date"] = _eutils.formatdate(localtime=True)
    msg["Message-ID"] = _eutils.make_msgid(domain=acc["email"].split("@")[1])
    irt = " ".join(re.findall(r"<[^<>\s]+>", str(b.get("inReplyTo") or "")))[:300]
    if irt:
        refs = re.findall(r"<[^<>\s]+>", str(b.get("references") or ""))
        msg["In-Reply-To"] = irt.split()[0]
        msg["References"] = " ".join((refs + [irt.split()[0]])[-20:])
    msg.set_content(body)
    s = _smtp_open(acc["provider"], acc["email"], acc["pw"])
    try:
        s.send_message(msg)
    except smtplib.SMTPRecipientsRefused:
        raise HTTPException(400, "mail:to")
    except (OSError, smtplib.SMTPException):
        raise HTTPException(502, "mail:smtp")
    finally:
        _smtp_close(s)
    with closing(db()) as c, c:
        c.execute("INSERT INTO mail_log(ts, day, user_id) VALUES(?,?,?)", (iso(now()), day, u["id"]))
    # Im Ordner "Gesendet" ablegen, wenn der Anbieter das nicht selbst macht (Gmail macht es selbst)
    if not MAIL_PROVIDERS[acc["provider"]].get("autosent") and acc.get("sent_folder"):
        try:
            m = _imap_open(acc["provider"], acc["email"], acc["pw"])
            try:
                m.append(_imap_quote(acc["sent_folder"]), "(\\Seen)", imaplib.Time2Internaldate(time.time()), msg.as_bytes())
            finally:
                _imap_close(m)
        except Exception:
            pass
    return {"ok": True, "messageId": msg["Message-ID"]}


# ----------------------------------------------------------------- Frontend
STATIC = Path(__file__).parent / "static"
app.mount("/fonts", StaticFiles(directory=STATIC / "fonts"), name="fonts")


@app.get("/", response_class=HTMLResponse)
def index():
    return FileResponse(STATIC / "index.html", headers={"Cache-Control": "no-cache"})


@app.get("/manifest.webmanifest")
def manifest():
    return FileResponse(STATIC / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/icon.svg")
def icon():
    return FileResponse(STATIC / "icon.svg", media_type="image/svg+xml")


@app.get("/{name}.png")
def icon_png(name: str):
    if name not in ("apple-touch-icon", "icon-192", "icon-512"):
        raise HTTPException(404)
    return FileResponse(STATIC / f"{name}.png", media_type="image/png", headers={"Cache-Control": "public, max-age=86400"})


# Produktseite unter mailcut.de; www und mailcut.app leiten dorthin weiter.
SITE = STATIC / "site"
SITE_HOST = "mailcut.de"
SITE_REDIRECT = {"www.mailcut.de", "mailcut.app", "www.mailcut.app"}
SITE_PAGES = {"/": "index.html", "/datenschutz": "datenschutz.html", "/datenschutz.html": "datenschutz.html"}
SITE_PASS = ("/fonts/", "/icon.svg", "/apple-touch-icon.png", "/icon-192.png", "/icon-512.png")


@app.middleware("http")
async def product_site(request: Request, call_next):
    host = (request.headers.get("host") or "").split(":")[0].lower()
    path = request.url.path
    if host in SITE_REDIRECT:
        return RedirectResponse("https://mailcut.de" + path, status_code=301)
    if host == SITE_HOST:
        if path in SITE_PAGES:
            return FileResponse(SITE / SITE_PAGES[path], headers={"Cache-Control": "no-cache"})
        if not path.startswith(SITE_PASS):
            return RedirectResponse("https://app.mailcut.de" + path, status_code=302)
    return await call_next(request)


@app.get("/admin", response_class=HTMLResponse)
def admin_page():
    return FileResponse(STATIC / "admin.html", headers={"Cache-Control": "no-cache"})


@app.middleware("http")
async def security_headers(request: Request, call_next):
    resp = await call_next(request)
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["Referrer-Policy"] = "same-origin"
    resp.headers["X-Frame-Options"] = "DENY"
    return resp
